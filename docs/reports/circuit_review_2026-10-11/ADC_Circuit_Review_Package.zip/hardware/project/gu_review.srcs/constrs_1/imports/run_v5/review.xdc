create_clock -name review_clk -period 10.000 [get_ports clk]
set_input_delay -clock review_clk 1.000 [get_ports {reset valid_in stage1_symbol[*] stage2_symbol[*] backend_raw_code[*] stage1_dither_positive stage2_dither_positive}]
set_output_delay -clock review_clk 1.000 [get_ports {valid_out final_code[*]}]
set_load 1.000 [get_ports {valid_out final_code[*]}]
