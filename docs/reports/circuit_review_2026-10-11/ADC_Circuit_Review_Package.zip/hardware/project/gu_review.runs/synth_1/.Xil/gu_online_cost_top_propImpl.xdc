set_property SRC_FILE_INFO {cfile:C:/Users/17765/.codex/visualizations/2026/10/11/01a128ab-7929-75a0-bab1-c54b7763a0c7/adc_circuit_review/hardware/project/gu_review.srcs/constrs_1/imports/run_v5/review.xdc rfile:../../../gu_review.srcs/constrs_1/imports/run_v5/review.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:4 export:INPUT save:INPUT read:READ} [current_design]
set_load 1.000 [get_ports {valid_out final_code[*]}]
